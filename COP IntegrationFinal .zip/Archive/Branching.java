import java.util.Scanner;

public class Branching {

	public static void han3(Scanner scan) {
		System.out.println("Operators, Condition Statements and Branching");
		int testscore = 85;
		char grade;

		// This is an if else loop and will take user input and then go through the
		// loop
		// Based on what the user input was, it will print out the grade that they
		// will recieve
		if (testscore >= 90) {
			grade = 'A';
		} else if (testscore >= 80) {
			grade = 'B';
		} else if (testscore >= 70) {
			grade = 'C';
		} else if (testscore >= 60) {
			grade = 'D';
		} else {
			grade = 'F';
		}
		System.out.println("Grade = " + grade);

		// Demonstrates what && and || stand for
		// && stands for AND
		// || stands for OR
		int value1 = 1;
		int value2 = 2;
		if ((value1 == 1) && (value2 == 2)) {
			System.out.println("value1 is 1 AND value2 is 2");
		}
		if ((value1 == 1) || (value2 == 1)) {
			System.out.println("value1 is 1 OR value2 is 1");
		}
	}

}
