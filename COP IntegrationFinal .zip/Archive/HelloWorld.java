
import java.util.Scanner;

public class HelloWorld {

	// The beginning of every programmers journey
	// 'tis the birth of a programmer

	public static void han1(Scanner scan) {
		System.out.println("Hello World!");

	}

}
