import java.util.Scanner;

public class Loops {

	public static void han6(Scanner scan) {
		System.out.println("Over and Over again");
		boolean continueProgram = true;
		int menuChoice = 0;
		while (continueProgram) {

			// It will loop through until you type in 2 and
			// it allows you to move forward in the program
			// Battle of wits, human or computer?

			System.out.println("Press 1 to continue or 2 to quit.");
			menuChoice = scan.nextInt();
			if (menuChoice == 2) {
				continueProgram = false;
			}

		}

	}

}
