
import java.util.Scanner;

public class Classes {

	public static void han4(Scanner scan) {
		System.out.println("Classes and Methods");
		printIntro();

		double livingRoomLength = 20;
		double livingRoomWidth = 30;
		System.out.println("The area of the living room is "
				+ getArea(livingRoomLength, livingRoomWidth));

		// Uses double to print out the area of the bedroom
		double bedoomLength = 15;
		double bedroomWidth = 25;
		System.out.println("The area of the bedroom room is "
				+ getArea(bedoomLength, bedroomWidth));

	}

	public static void printIntro() {
		System.out.println("Methods!");
	}

	public static double getArea(double length, double width) {
		return length * width;
	}

}