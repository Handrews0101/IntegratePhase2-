//This class is strictly used to provide information for class TwoDArray
// I node it, but do you node it? 

class Node {
	int data;
	Node next;

	Node(int d) {
		data = d;
		next = null;
	}
}