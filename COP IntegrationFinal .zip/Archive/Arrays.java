import java.util.Scanner;

public class Arrays {

	public static void han7(Scanner scan) {
		System.out.println("Array Demonstration");
		int[] anArray = { 100, 200, 300 };

		for (int i = 0; i < anArray.length; i++) {
			System.out.println(anArray[i]);
		}

		// while not found and i < anArray.length
		// This searches for a particular int in the given array
		// using a for loop
		for (int i = 0; i < anArray.length; i++) {
			if (anArray[i] == 250) {
				// Not found = false
				// Location where found = i
				// If it is found it will print out "Today is your lucky day!"
				System.out.println("To day is your lucky day!");
			}

		}
		// if the int is not found, it will print out "Maybe another day"
		System.out.println("Maybe another day");
		// else found at location i
	}
}
