import java.util.Scanner;

public class Data {

	public static void han2(Scanner scan) {

		System.out.println("Various Elements of Java");
		/*
		 * Boolean: True or false, 0 or 1, data types, 1 bit in size
		 * 
		 * byte: 8-bit signed two's complement integer, used for saving memory in
		 * large arrays. Value -128 to 127
		 * 
		 * char: a char is one single character, priitive type. You use single
		 * quotes. Ex: 'a'
		 * 
		 * short: 16-bit signed two's complement integer. used to save memory in
		 * large arrays, value -32,768 to 32,767
		 * 
		 * int: 32-bit signed two's complement integer, value -2^31 to (2^31)-1
		 * 
		 * long: a 64-bit two's complement integer. value -2^63 to (2^63)-1
		 * 
		 * float: single-precision 32-bit IEEE 754 floating point. Use a float
		 * instead of double if you need to save memory in large arrays of floating
		 * point numbers.
		 * 
		 * double: designed especially for scientific calculations, where
		 * approximation errors are acceptable. 64-bit
		 * 
		 * variable: a piece of memory that can contain a data value.
		 */

		int num1; // variable declaration
		num1 = 1; // assignment
		int num2 = 2; // declaration + assignment = initialization
		System.out.println("num1 + num2 = " + (num1 + num2));

		String palindrome = "Hannah"; // String is a class
		// classes have methods

		// This shows the length of the palidrome aka my name (Hannah)
		System.out.println("The length of the string is " + palindrome.length());

		payProgram(scan);
		nextVsNextLine(scan);
		classDemo();

	}

	public static void payProgram(Scanner keyboard) {
		// Get Input, User puts in their name
		// Utalizes the string data type
		String name;
		System.out.print("Enter your name: ");
		name = keyboard.nextLine();

		// Gets the users pay rate and also utilizes the double data type which
		// Will take their number and put a decimal.
		// Ex: input = 5 --> 5.0
		double payRate;
		System.out.print("Enter your hourly pay rate: ");
		payRate = keyboard.nextDouble();

		// Utilizes the int data type while asking the user what their hours
		// worked are
		int hours;
		System.out.print("Enter the number of hours worked: ");
		hours = keyboard.nextInt();

		// Based on what they entered above, their name,
		// pay rate, and hours worked will print out on individual
		// lines as shown below
		System.out.println("Here are the values that you entered:");
		System.out.println(name);
		System.out.println(payRate);
		System.out.println(hours);
	}

	public static void nextVsNextLine(Scanner keyboard) {
		// nextInt doesn't consume the Enter keystroke
		// Uses keystrokes to go to the next question
		// Consume left-over newline
		keyboard.nextLine();
		System.out.println("Enter another name:");
		String name = keyboard.nextLine();
		System.out.println("The name that you entered was " + name);
		System.out.println("Enter a number:");
		double rate = keyboard.nextDouble();
		System.out.println("The number that you entered was " + rate);
		System.out.println("Enter first name:");

		// reads input until a space
		String firstName = keyboard.next();
		System.out.println("The name that you entered was " + firstName);
		System.out.println("Enter address:");

		// reads input including spaces
		String address = keyboard.nextLine();

		// until the end of line \n
		System.out.println("The address that you entered was " + address);
	}

	public static void classDemo() {
		// Class Demonstration
		// Creates a class using a user friendly phone :)
		CellPhone myPhone = new CellPhone();
		myPhone.setManufacturer("Apple");
		System.out.println("The best phone manufacturer is: " + myPhone.getManufacturer());
	}
}

class CellPhone {

	private String manufacturer;

	// Demonstrates a getter and setter using the class
	// above and the phone manufacturer, again
	// the user friendly company.. :)
	public void setManufacturer(String manufact) {
		manufacturer = manufact;
	}

	public String getManufacturer() {
		return manufacturer;
	}
}