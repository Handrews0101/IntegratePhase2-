import java.util.Scanner;

public class Inheritance {

	public static void han10(Scanner scan) {
		System.out.println("Animals Gone wild");
		Cat felix = new Cat();
		Dog fido = new Dog();
		Fox lady = new Fox();
		Animal[] myPets = { felix, fido, lady }; // this is polymorphism
		for (Animal anAnimal : myPets) {
			System.out.println(anAnimal.showSpecies());
			anAnimal.makeSound();
		}
	}
}

class Animal {

	protected String species;

	public String showSpecies() {
		return "Animal";
	}

	public void makeSound() {
		System.out.println("What does the fox say?");
		System.out.println("Ring ding ding ding");
	}
}

class Dog extends Animal {

	public Dog() {
		species = "Canine"; // this demonstrates inheritance
	}

	public String showSpecies() {
		return "Dog";
	}

	public void makeSound() {
		System.out.println("Woof");
	}

}

class Cat extends Animal {

	public Cat() {
		species = "The one wierd people like";
	}

	public String showSpecies() {
		return species;
	}

	public void makeSound() {
		System.out.println("Meow");
	}
}

class Fox extends Animal {

	public Fox() {
		species = "What does the fox say???";
	}

	public String showSpecies() {
		return species;
	}

	public void makeSound() {
		System.out.println("RING DING DING DING DING");
	}
}
