import java.util.Scanner;

public class Objects {

	public static void han5(Scanner scan) {
		Player p1 = new Player();
		Player p2 = new Player();

		p1.setScore(100);
		p2.setScore(200);

		// The data for this class will be pulled from the class Player
		
		System.out.println("Player 1 score = " + p1.getScore());
		System.out.println("Player 2 score = " + p2.getScore());
	}
}