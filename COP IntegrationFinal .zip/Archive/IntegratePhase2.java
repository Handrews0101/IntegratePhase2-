import java.util.Scanner;

public class IntegratePhase2 {

	public static void main(String[] args) throws java.lang.Exception {

		// This class calls the various modules and classes 
		// that are used to demonstrate various topics from class. 
		// It does this by first naming the class, and then creating an instance of that 
		// class and scanning it. It is based off the examples used in class and then 
		// commented out and fixed so that it will run through the various elements independently 
		// It will start by doing the first things we learned this semester and move forward
		// It's like the yearbook of programming, welcome to COP 2006. Please hold back your tears 
		
		
		Scanner scan = new Scanner(System.in);

		HelloWorld helloW = new HelloWorld();
		helloW.han1(scan);

		System.out.println();

		Data dataNew = new Data();
		dataNew.han2(scan);

		System.out.println();

		Branching branching = new Branching();
		branching.han3(scan);

		System.out.println();

		Classes classesNew = new Classes();
		classesNew.han4(scan);

		System.out.println();

		Objects objNew = new Objects();
		objNew.han5(scan);

		System.out.println();

		Loops loopyThrough = new Loops();
		loopyThrough.han6(scan);

		System.out.println();

		Arrays myArrayClass = new Arrays();
		myArrayClass.han7(scan);

		System.out.println();

		StringsTwo newString = new StringsTwo();
		newString.han8(scan);

		System.out.println();

		TwoDArray newArray = new TwoDArray();
		newArray.han9(scan);

		System.out.println();

		Java8Tester testerJ = new Java8Tester();
		testerJ.java8demo();

		System.out.println();

		Inheritance inheritNew = new Inheritance();
		inheritNew.han10(scan);

		System.out.println();

		Exceptions exception = new Exceptions();
		exception.han11(scan);

		System.out.println();

		Dictionaries narieNew = new Dictionaries();
		narieNew.han12(scan);

		System.out.println();

	}
}
